#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    // Initialiser le générateur de nombres aléatoires avec le temps actuel
    srand(time(NULL));

    // Générer un nombre aléatoire entre 0 et RAND_MAX
    int nombre_aleatoire = rand();

    // Afficher le nombre aléatoire
    printf("Nombre aléatoire: %d\n", nombre_aleatoire);

    return 0;
}
